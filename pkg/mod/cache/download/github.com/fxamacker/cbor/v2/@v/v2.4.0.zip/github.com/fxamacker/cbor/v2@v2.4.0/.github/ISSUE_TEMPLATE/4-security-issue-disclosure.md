---
name: "\U0001F513 Security issue disclosure"
about: Report a security issue in fxamacker/cbor
title: ''
labels: ''
assignees: ''

---

<!--

🛑 PLEASE DO NOT DISCLOSE THE ISSUE HERE BECAUSE IT IS PUBLIC.

Email security disclosures to:   faye.github@gmail.com

-->
